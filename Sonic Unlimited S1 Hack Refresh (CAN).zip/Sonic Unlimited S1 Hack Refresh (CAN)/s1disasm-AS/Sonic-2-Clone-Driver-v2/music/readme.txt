These are SMPS2ASM-converted Sonic 1 music files, which can theoretically be made to work with any SMPS driver.

You can find more of these, from different games, at:
http://forums.sonicretro.org/index.php?showtopic=26876
