These are SMPS2ASM-converted Sonic 2 music files, which can theoretically be made to work with any SMPS driver.

You can find more of these, from different games, at:
http://forums.sonicretro.org/index.php?showtopic=26876

Note that these are not stock; I (Clownacy) have made modifications to these files, to fix several bug-causing mistakes within. The mistakes fixed include:
- Incorrect smpsVcTotalLevel values in '84 - OOZ.asm'
- Incorrect smpsVcTotalLevel values in '95 - SWEET SWEET SWEET.asm'
- Incorrect smpsVcTotalLevel values in '99 - Title Screen.asm'
- Incorrect smpsAlterVol usage in '83 - MCZ 2P.asm'
- Incorrect smpsAlterVol usage in '84 - OOZ.asm'
- Incorrect smpsAlterVol usage in '87 - ARZ.asm'
- Incorrect smpsAlterVol usage in '8C - EHZ 2P.asm'
- Incorrect smpsAlterVol usage in '8D - SCZ.asm'
- Incorrect smpsAlterVol usage in '90 - HPZ.asm'
- Incorrect smpsAlterVol usage in '9E - Credits.asm'
